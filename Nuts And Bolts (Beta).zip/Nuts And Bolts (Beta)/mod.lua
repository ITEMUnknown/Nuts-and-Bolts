local parts_map = {
	wpn_fps_ass_74_b_standard = "wpn_fps_ass_74_ns_standard",
	wpn_fps_ass_g36_fg_c = "wpn_fps_ass_g36_ns_df",
	wpn_fps_ass_g36_fg_k = "wpn_fps_ass_g36_ns_df",
	wpn_fps_ass_g36_fg_ksk = "wpn_fps_ass_g36_ns_df",
	wpn_fps_aug_b_long = "wpn_fps_aug_ns_df",
	wpn_fps_aug_b_medium = "wpn_fps_aug_ns_df",
	wpn_fps_aug_b_short = "wpn_fps_aug_ns_df",
	wpn_fps_upg_ak_b_ak105 = "wpn_fps_upg_ak_ns_ak105",
	wpn_fps_lmg_rpk_b_standard = "wpn_fps_lmg_rpk_ns_df",
}


Hooks:PostHook( BlackMarketTweakData, "_init_weapon_mods", "nab__init_weapon_mods", function(_, tweak_data)
	local weapon_factory = tweak_data.weapon.factory

	local dummy_unit = "units/payday2/weapons/wpn_upg_dummy/wpn_upg_dummy"
	local function insert_part_to_adds(id_1, id_2)
		local part_1, part_2 = weapon_factory.parts[id_1], weapon_factory.parts[id_2]

		if not part_1 or not part_2 then
			log("[Nuts & Bolts] ERROR: Something is missing:", id_1, type(part_1), id_2, type(part_2))

			return
		end

		part_1.adds = part_1.adds or {}
		if not table.contains(part_1.adds, id_2) then
    table.insert(part_1.adds, id_2)
end

		if part_2.overrides_set then
			return
		end

		for _, data in pairs(weapon_factory) do
			local uses_parts = type(data) == "table" and data.uses_parts

			if uses_parts then
				local contains_part_1 = table.contains(uses_parts, id_1)

				if contains_part_1 then
					for _, name in ipairs(uses_parts) do
						local part = weapon_factory.parts[name]

						if part and part.type == part_2.type then
							part.override = part.override or {}
							part.override[id_2] = part.override[id_2] or {}
							part.override[id_2].unit = dummy_unit
							part.override[id_2].third_unit = dummy_unit
						end
					end

					part_2.overrides_set = true
				end
			end
		end
	end

	for id_1, id_2 in pairs(parts_map) do
		insert_part_to_adds(id_1, id_2)
	end
end )
